//angular modules
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

//app modules
import { MoviesModule } from './modules/movies/movies.module';
import { MoviesRoutingModule } from './modules/movies/movies-routing.module';
import { AppRoutingModule } from './app-routing.module';

//Components
import { AppComponent } from './app.component';
import { CharactersListComponent } from './components/characters-list/characters-list.component';
import { CharacterComponent } from './components/character/character.component';
import { PageNotFoundComponent } from './components/page-not-found.component';



@NgModule({
  declarations: [
    AppComponent,
    CharactersListComponent,
    CharacterComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    MoviesModule,  //this need to be above
    AppRoutingModule //of this

  ],
  providers: [ ],
  bootstrap: [AppComponent]
})
export class AppModule { }
